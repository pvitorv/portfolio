<?php if (isset($component)) { $__componentOriginal5863877a5171c196453bfa0bd807e410 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5863877a5171c196453bfa0bd807e410 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.app','data' => ['title' => 'Meu Portfolio']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Meu Portfolio']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

    <div class="min-h-screen flex flex-col">
        <?php if (isset($component)) { $__componentOriginal9ad8060e833be98a16aaaccaeef88ec5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ad8060e833be98a16aaaccaeef88ec5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.app-navbar','data' => ['brand' => 'Meu Portfolio','variant' => 'glass']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['brand' => 'Meu Portfolio','variant' => 'glass']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

             <?php $__env->slot('links', null, []); ?> 
                <a href="#inicio" class="px-3 py-2 rounded-lg hover:bg-black/5 dark:hover:bg-white/5">Início</a>
                <a href="#sobre" class="px-3 py-2 rounded-lg hover:bg-black/5 dark:hover:bg-white/5">Sobre</a>
                <a href="#projetos" class="px-3 py-2 rounded-lg hover:bg-black/5 dark:hover:bg-white/5">Projetos</a>
                <a href="#contato" class="px-3 py-2 rounded-lg hover:bg-black/5 dark:hover:bg-white/5">Contato</a>
                <a href="<?php echo e(route('login')); ?>" class="px-3 py-2 rounded-lg hover:bg-black/5 dark:hover:bg-white/5">Entrar</a>
             <?php $__env->endSlot(); ?>
            <?php if (isset($component)) { $__componentOriginal4ba4b6a015091d2c96934fb516198f40 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4ba4b6a015091d2c96934fb516198f40 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.app-theme-toggle','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-theme-toggle'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4ba4b6a015091d2c96934fb516198f40)): ?>
<?php $attributes = $__attributesOriginal4ba4b6a015091d2c96934fb516198f40; ?>
<?php unset($__attributesOriginal4ba4b6a015091d2c96934fb516198f40); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4ba4b6a015091d2c96934fb516198f40)): ?>
<?php $component = $__componentOriginal4ba4b6a015091d2c96934fb516198f40; ?>
<?php unset($__componentOriginal4ba4b6a015091d2c96934fb516198f40); ?>
<?php endif; ?>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ad8060e833be98a16aaaccaeef88ec5)): ?>
<?php $attributes = $__attributesOriginal9ad8060e833be98a16aaaccaeef88ec5; ?>
<?php unset($__attributesOriginal9ad8060e833be98a16aaaccaeef88ec5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ad8060e833be98a16aaaccaeef88ec5)): ?>
<?php $component = $__componentOriginal9ad8060e833be98a16aaaccaeef88ec5; ?>
<?php unset($__componentOriginal9ad8060e833be98a16aaaccaeef88ec5); ?>
<?php endif; ?>

        <main class="flex-1 max-w-7xl mx-auto w-full px-4 sm:px-6 lg:px-8 py-12">
            
            <section id="inicio" class="text-center py-16">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(isset($profile) && $profile->photo_display_url): ?>
                    <img src="<?php echo e($profile->photo_display_url); ?>" alt="<?php echo e($profile->name); ?>" class="w-24 h-24 rounded-full object-cover mx-auto mb-4 border-2 border-gray-200 dark:border-gray-700" />
                <?php else: ?>
                    <?php
                        $initials = isset($profile) && $profile->name ? implode('', array_map(fn($w) => mb_substr($w, 0, 1), array_slice(preg_split('/\s+/', $profile->name), 0, 2))) : '?';
                    ?>
                    <?php if (isset($component)) { $__componentOriginal39c070033cb52466cd2ed46ef06fa55e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal39c070033cb52466cd2ed46ef06fa55e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.app-avatar','data' => ['size' => 'xl','initials' => $initials,'class' => 'mx-auto mb-4']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-avatar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['size' => 'xl','initials' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($initials),'class' => 'mx-auto mb-4']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal39c070033cb52466cd2ed46ef06fa55e)): ?>
<?php $attributes = $__attributesOriginal39c070033cb52466cd2ed46ef06fa55e; ?>
<?php unset($__attributesOriginal39c070033cb52466cd2ed46ef06fa55e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal39c070033cb52466cd2ed46ef06fa55e)): ?>
<?php $component = $__componentOriginal39c070033cb52466cd2ed46ef06fa55e; ?>
<?php unset($__componentOriginal39c070033cb52466cd2ed46ef06fa55e); ?>
<?php endif; ?>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                <h1 class="text-4xl font-bold text-gray-900 dark:text-white mb-2">Olá, sou <?php echo e(isset($profile) ? $profile->name : 'Seu Nome'); ?></h1>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(isset($profile) && $profile->title): ?>
                    <p class="text-lg text-gray-600 dark:text-gray-400 max-w-2xl mx-auto mb-6"><?php echo e($profile->title); ?></p>
                <?php else: ?>
                    <p class="text-lg text-gray-600 dark:text-gray-400 max-w-2xl mx-auto mb-6">Desenvolvedor / Designer</p>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                <div class="flex gap-3 justify-center flex-wrap">
                    <a href="#projetos" class="inline-flex items-center justify-center font-medium rounded-lg px-5 py-2.5 text-base bg-blue-600 text-white hover:bg-blue-700 dark:bg-blue-500 dark:hover:bg-blue-600">Ver projetos</a>
                    <a href="#sobre" class="inline-flex items-center justify-center font-medium rounded-lg px-5 py-2.5 text-base border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-800">Sobre mim</a>
                </div>
            </section>

            
            <section class="grid grid-cols-1 md:grid-cols-2 gap-6 py-8">
                <?php if (isset($component)) { $__componentOriginal1ffef043f2830bf5bd33012ad2c48846 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1ffef043f2830bf5bd33012ad2c48846 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.app-stat-card','data' => ['label' => 'Projetos','value' => isset($projects) ? (string) $projects->count() : '0']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-stat-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Projetos','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(isset($projects) ? (string) $projects->count() : '0')]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1ffef043f2830bf5bd33012ad2c48846)): ?>
<?php $attributes = $__attributesOriginal1ffef043f2830bf5bd33012ad2c48846; ?>
<?php unset($__attributesOriginal1ffef043f2830bf5bd33012ad2c48846); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1ffef043f2830bf5bd33012ad2c48846)): ?>
<?php $component = $__componentOriginal1ffef043f2830bf5bd33012ad2c48846; ?>
<?php unset($__componentOriginal1ffef043f2830bf5bd33012ad2c48846); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginal593082f5d9bbe85e64b8909ad2db569b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal593082f5d9bbe85e64b8909ad2db569b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.app-card','data' => ['variant' => 'outline','padding' => 'md','class' => 'flex flex-col h-full']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['variant' => 'outline','padding' => 'md','class' => 'flex flex-col h-full']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

                    <div class="flex flex-col h-full justify-between">
                        <div>
                            <span class="text-sm font-medium text-gray-500 dark:text-gray-400 block mb-1">Use este projeto</span>
                            <p class="text-gray-900 dark:text-white font-semibold">Crie seu próprio portfólio</p>
                        </div>
                        <p class="text-gray-600 dark:text-gray-400 text-sm mt-2 mb-4 line-clamp-2">Clone o repositório, configure o banco e siga o passo a passo.</p>
                        <a href="<?php echo e(route('docs.criar-seu-portfolio')); ?>" class="inline-flex items-center justify-center font-medium rounded-lg px-4 py-2 text-sm bg-gray-900 dark:bg-gray-100 text-white dark:text-gray-900 hover:bg-gray-800 dark:hover:bg-gray-200 focus:outline-none focus:ring-2 focus:ring-gray-500 focus:ring-offset-2 dark:focus:ring-offset-gray-900 w-fit">
                            Ver passo a passo
                            <svg class="w-4 h-4 ml-1.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"/></svg>
                        </a>
                    </div>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal593082f5d9bbe85e64b8909ad2db569b)): ?>
<?php $attributes = $__attributesOriginal593082f5d9bbe85e64b8909ad2db569b; ?>
<?php unset($__attributesOriginal593082f5d9bbe85e64b8909ad2db569b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal593082f5d9bbe85e64b8909ad2db569b)): ?>
<?php $component = $__componentOriginal593082f5d9bbe85e64b8909ad2db569b; ?>
<?php unset($__componentOriginal593082f5d9bbe85e64b8909ad2db569b); ?>
<?php endif; ?>
            </section>

            
            <section id="sobre" class="py-12">
                <?php if (isset($component)) { $__componentOriginal593082f5d9bbe85e64b8909ad2db569b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal593082f5d9bbe85e64b8909ad2db569b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.app-card','data' => ['title' => 'Sobre mim','variant' => 'glass','padding' => 'lg']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Sobre mim','variant' => 'glass','padding' => 'lg']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(isset($profile) && $profile->bio): ?>
                        <p class="text-gray-600 dark:text-gray-400 whitespace-pre-line"><?php echo e($profile->bio); ?></p>
                    <?php else: ?>
                        <p class="text-gray-600 dark:text-gray-400">Edite seu perfil no admin para exibir seu currículo e dados aqui.</p>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal593082f5d9bbe85e64b8909ad2db569b)): ?>
<?php $attributes = $__attributesOriginal593082f5d9bbe85e64b8909ad2db569b; ?>
<?php unset($__attributesOriginal593082f5d9bbe85e64b8909ad2db569b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal593082f5d9bbe85e64b8909ad2db569b)): ?>
<?php $component = $__componentOriginal593082f5d9bbe85e64b8909ad2db569b; ?>
<?php unset($__componentOriginal593082f5d9bbe85e64b8909ad2db569b); ?>
<?php endif; ?>
            </section>

            
            <section id="projetos" class="py-12">
                <h2 class="text-2xl font-bold text-gray-900 dark:text-white mb-6">Projetos</h2>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(isset($projects) && $projects->isNotEmpty()): ?>
                    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoop($loop->index); ?><?php endif; ?>
                            <?php if (isset($component)) { $__componentOriginal593082f5d9bbe85e64b8909ad2db569b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal593082f5d9bbe85e64b8909ad2db569b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.app-card','data' => ['variant' => 'glass','padding' => 'none','class' => 'overflow-hidden flex flex-col h-full']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['variant' => 'glass','padding' => 'none','class' => 'overflow-hidden flex flex-col h-full']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

                                
                                <a href="<?php echo e($project->url); ?>" target="_blank" rel="noopener noreferrer" class="block aspect-video bg-gray-200 dark:bg-gray-700 overflow-hidden">
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($project->thumbnail_display_url): ?>
                                        <img
                                            src="<?php echo e($project->thumbnail_display_url); ?>"
                                            alt="<?php echo e($project->display_name); ?>"
                                            class="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
                                            loading="lazy"
                                            onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';"
                                        />
                                        <div class="w-full h-full hidden items-center justify-center text-gray-400 dark:text-gray-500 bg-gray-200 dark:bg-gray-700" style="min-height: 140px;">
                                            <svg class="w-12 h-12" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 12a9 9 0 01-9 9m9-9a9 9 0 00-9-9m9 9H3m9 9a9 9 0 01-9-9m9 9c1.657 0 3-4.03 3-9s-1.343-9-3-9m0 18c-1.657 0-3-4.03-3-9s1.343-9 3-9m-9 9a9 9 0 019-9"/></svg>
                                        </div>
                                    <?php else: ?>
                                        <div class="w-full h-full flex items-center justify-center text-gray-400 dark:text-gray-500" style="min-height: 140px;">
                                            <svg class="w-12 h-12" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 12a9 9 0 01-9 9m9-9a9 9 0 00-9-9m9 9H3m9 9a9 9 0 01-9-9m9 9c1.657 0 3-4.03 3-9s-1.343-9-3-9m0 18c-1.657 0-3-4.03-3-9s1.343-9 3-9m-9 9a9 9 0 019-9"/></svg>
                                        </div>
                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                </a>
                                <div class="p-5 flex-1 flex flex-col" x-data="{ expanded: false }">
                                    <h3 class="text-lg font-semibold text-gray-900 dark:text-white mb-2"><?php echo e($project->display_name); ?></h3>
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($project->description): ?>
                                        <p class="text-gray-600 dark:text-gray-400 text-sm flex-1 transition-all"
                                           :class="expanded ? '' : 'line-clamp-4'"
                                        ><?php echo e($project->description); ?></p>
                                        <div class="flex gap-2 mt-1" x-cloak>
                                            <button type="button"
                                                    @click="expanded = true"
                                                    x-show="!expanded"
                                                    class="text-sm font-medium text-blue-600 dark:text-blue-400 hover:underline focus:outline-none"
                                            >Ler mais</button>
                                            <button type="button"
                                                    @click="expanded = false"
                                                    x-show="expanded"
                                                    class="text-sm font-medium text-blue-600 dark:text-blue-400 hover:underline focus:outline-none"
                                            >Ler menos</button>
                                        </div>
                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                    <div class="mt-4 flex flex-wrap gap-2">
                                        <a href="<?php echo e($project->url); ?>" target="_blank" rel="noopener noreferrer" class="inline-flex items-center justify-center font-medium rounded-lg px-4 py-2 text-sm bg-blue-600 text-white hover:bg-blue-700 dark:bg-blue-500 dark:hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 dark:focus:ring-offset-gray-900">
                                            Ver projeto
                                            <svg class="w-4 h-4 ml-1.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"/></svg>
                                        </a>
                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($project->github_url ?? null): ?>
                                            <a href="<?php echo e($project->github_url); ?>" target="_blank" rel="noopener noreferrer" class="inline-flex items-center justify-center font-medium rounded-lg px-4 py-2 text-sm border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-800">
                                                GitHub
                                                <svg class="w-4 h-4 ml-1.5" fill="currentColor" viewBox="0 0 24 24"><path d="M12 0c-6.626 0-12 5.373-12 12 0 5.302 3.438 9.8 8.207 11.387.599.111.793-.261.793-.577v-2.234c-3.338.726-4.033-1.416-4.033-1.416-.546-1.387-1.333-1.756-1.333-1.756-1.089-.745.083-.729.083-.729 1.205.084 1.839 1.237 1.839 1.237 1.07 1.834 2.807 1.304 3.492.997.107-.775.418-1.305.762-1.604-2.665-.305-5.467-1.334-5.467-5.931 0-1.311.469-2.381 1.236-3.221-.124-.303-.535-1.524.117-3.176 0 0 1.008-.322 3.301 1.23.957-.266 1.983-.399 3.003-.404 1.02.005 2.047.138 3.006.404 2.291-1.552 3.297-1.23 3.297-1.23.653 1.653.242 2.874.118 3.176.77.84 1.235 1.911 1.235 3.221 0 4.609-2.807 5.624-5.479 5.921.43.372.823 1.102.823 2.222v3.293c0 .319.192.694.801.576 4.765-1.589 8.199-6.086 8.199-11.386 0-6.627-5.373-12-12-12z"/></svg>
                                            </a>
                                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                    </div>
                                </div>
                             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal593082f5d9bbe85e64b8909ad2db569b)): ?>
<?php $attributes = $__attributesOriginal593082f5d9bbe85e64b8909ad2db569b; ?>
<?php unset($__attributesOriginal593082f5d9bbe85e64b8909ad2db569b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal593082f5d9bbe85e64b8909ad2db569b)): ?>
<?php $component = $__componentOriginal593082f5d9bbe85e64b8909ad2db569b; ?>
<?php unset($__componentOriginal593082f5d9bbe85e64b8909ad2db569b); ?>
<?php endif; ?>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                    </div>
                    <p class="mt-4 text-sm text-gray-500 dark:text-gray-400">
                        <a href="<?php echo e(route('login')); ?>" class="hover:underline">Entrar para gerenciar</a>
                    </p>
                <?php else: ?>
                    <?php if (isset($component)) { $__componentOriginalbdcf26aa50165d2e417b981b3bead1be = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbdcf26aa50165d2e417b981b3bead1be = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.app-empty-state','data' => ['title' => 'Nenhum projeto publicado','description' => 'Os projetos cadastrados no mini CMS aparecerão aqui.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-empty-state'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Nenhum projeto publicado','description' => 'Os projetos cadastrados no mini CMS aparecerão aqui.']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

                        <a href="<?php echo e(route('login')); ?>" class="inline-flex items-center justify-center font-medium rounded-lg px-4 py-2 text-sm bg-blue-600 text-white hover:bg-blue-700 dark:bg-blue-500 dark:hover:bg-blue-600">Entrar</a>
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbdcf26aa50165d2e417b981b3bead1be)): ?>
<?php $attributes = $__attributesOriginalbdcf26aa50165d2e417b981b3bead1be; ?>
<?php unset($__attributesOriginalbdcf26aa50165d2e417b981b3bead1be); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbdcf26aa50165d2e417b981b3bead1be)): ?>
<?php $component = $__componentOriginalbdcf26aa50165d2e417b981b3bead1be; ?>
<?php unset($__componentOriginalbdcf26aa50165d2e417b981b3bead1be); ?>
<?php endif; ?>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </section>
        </main>

        
        <footer id="contato" class="mt-auto">
            <section class="backdrop-blur-md bg-white/70 dark:bg-gray-900/70 border-t border-white/20 dark:border-gray-700/30">
                <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
                    <h2 class="text-2xl font-bold text-gray-900 dark:text-white mb-8">Contato</h2>

                    <div class="grid grid-cols-1 lg:grid-cols-2 gap-10 lg:gap-16">
                        
                        <div class="space-y-6">
                            <p class="text-gray-600 dark:text-gray-400">Entre em contato por e-mail, redes ou use o formulário ao lado.</p>
                            <dl class="space-y-3 text-sm">
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(isset($profile) && $profile->email): ?>
                                    <div>
                                        <dt class="font-medium text-gray-500 dark:text-gray-400">E-mail</dt>
                                        <dd><a href="mailto:<?php echo e($profile->email); ?>" class="text-blue-600 dark:text-blue-400 hover:underline"><?php echo e($profile->email); ?></a></dd>
                                    </div>
                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(isset($profile) && $profile->phone): ?>
                                    <div>
                                        <dt class="font-medium text-gray-500 dark:text-gray-400">Telefone</dt>
                                        <dd><a href="tel:<?php echo e(preg_replace('/\s+/', '', $profile->phone)); ?>" class="text-gray-900 dark:text-white hover:underline"><?php echo e($profile->phone); ?></a></dd>
                                    </div>
                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(isset($profile) && $profile->location): ?>
                                    <div>
                                        <dt class="font-medium text-gray-500 dark:text-gray-400">Localização</dt>
                                        <dd class="text-gray-900 dark:text-white"><?php echo e($profile->location); ?></dd>
                                    </div>
                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </dl>
                            <div class="flex flex-wrap gap-4 pt-2">
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(isset($profile) && $profile->linkedin_url): ?>
                                    <a href="<?php echo e($profile->linkedin_url); ?>" target="_blank" rel="noopener noreferrer" class="inline-flex items-center gap-2 text-gray-600 dark:text-gray-400 hover:text-blue-600 dark:hover:text-blue-400 transition-colors">
                                        <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/></svg>
                                        LinkedIn
                                    </a>
                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(isset($profile) && $profile->github_url): ?>
                                    <a href="<?php echo e($profile->github_url); ?>" target="_blank" rel="noopener noreferrer" class="inline-flex items-center gap-2 text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white transition-colors">
                                        <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M12 0c-6.626 0-12 5.373-12 12 0 5.302 3.438 9.8 8.207 11.387.599.111.793-.261.793-.577v-2.234c-3.338.726-4.033-1.416-4.033-1.416-.546-1.387-1.333-1.756-1.333-1.756-1.089-.745.083-.729.083-.729 1.205.084 1.839 1.237 1.839 1.237 1.07 1.834 2.807 1.304 3.492.997.107-.775.418-1.305.762-1.604-2.665-.305-5.467-1.334-5.467-5.931 0-1.311.469-2.381 1.236-3.221-.124-.303-.535-1.524.117-3.176 0 0 1.008-.322 3.301 1.23.957-.266 1.983-.399 3.003-.404 1.02.005 2.047.138 3.006.404 2.291-1.552 3.297-1.23 3.297-1.23.653 1.653.242 2.874.118 3.176.77.84 1.235 1.911 1.235 3.221 0 4.609-2.807 5.624-5.479 5.921.43.372.823 1.102.823 2.222v3.293c0 .319.192.694.801.576 4.765-1.589 8.199-6.086 8.199-11.386 0-6.627-5.373-12-12-12z"/></svg>
                                        GitHub
                                    </a>
                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </div>
                        </div>

                        
                        <div>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('success')): ?>
                                <?php if (isset($component)) { $__componentOriginal698857124c69843c95d3799237fd2d1a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal698857124c69843c95d3799237fd2d1a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.app-alert','data' => ['variant' => 'success','class' => 'mb-4']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['variant' => 'success','class' => 'mb-4']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>
<?php echo e(session('success')); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal698857124c69843c95d3799237fd2d1a)): ?>
<?php $attributes = $__attributesOriginal698857124c69843c95d3799237fd2d1a; ?>
<?php unset($__attributesOriginal698857124c69843c95d3799237fd2d1a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal698857124c69843c95d3799237fd2d1a)): ?>
<?php $component = $__componentOriginal698857124c69843c95d3799237fd2d1a; ?>
<?php unset($__componentOriginal698857124c69843c95d3799237fd2d1a); ?>
<?php endif; ?>
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('error')): ?>
                                <?php if (isset($component)) { $__componentOriginal698857124c69843c95d3799237fd2d1a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal698857124c69843c95d3799237fd2d1a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.app-alert','data' => ['variant' => 'danger','class' => 'mb-4']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['variant' => 'danger','class' => 'mb-4']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>
<?php echo e(session('error')); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal698857124c69843c95d3799237fd2d1a)): ?>
<?php $attributes = $__attributesOriginal698857124c69843c95d3799237fd2d1a; ?>
<?php unset($__attributesOriginal698857124c69843c95d3799237fd2d1a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal698857124c69843c95d3799237fd2d1a)): ?>
<?php $component = $__componentOriginal698857124c69843c95d3799237fd2d1a; ?>
<?php unset($__componentOriginal698857124c69843c95d3799237fd2d1a); ?>
<?php endif; ?>
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            <form action="<?php echo e(route('contact.store')); ?>" method="POST" class="space-y-4">
                                <?php echo csrf_field(); ?>
                                <?php if (isset($component)) { $__componentOriginalde6ec2c366000a45d20b4a5db26717c7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalde6ec2c366000a45d20b4a5db26717c7 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.app-input','data' => ['name' => 'name','label' => 'Seu nome','value' => old('name'),'placeholder' => 'Nome completo','required' => true,'error' => $errors->first('name')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'name','label' => 'Seu nome','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(old('name')),'placeholder' => 'Nome completo','required' => true,'error' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->first('name'))]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalde6ec2c366000a45d20b4a5db26717c7)): ?>
<?php $attributes = $__attributesOriginalde6ec2c366000a45d20b4a5db26717c7; ?>
<?php unset($__attributesOriginalde6ec2c366000a45d20b4a5db26717c7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalde6ec2c366000a45d20b4a5db26717c7)): ?>
<?php $component = $__componentOriginalde6ec2c366000a45d20b4a5db26717c7; ?>
<?php unset($__componentOriginalde6ec2c366000a45d20b4a5db26717c7); ?>
<?php endif; ?>
                                <?php if (isset($component)) { $__componentOriginalde6ec2c366000a45d20b4a5db26717c7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalde6ec2c366000a45d20b4a5db26717c7 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.app-input','data' => ['name' => 'email','label' => 'Seu e-mail','type' => 'email','value' => old('email'),'placeholder' => 'seu@email.com','required' => true,'error' => $errors->first('email')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'email','label' => 'Seu e-mail','type' => 'email','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(old('email')),'placeholder' => 'seu@email.com','required' => true,'error' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->first('email'))]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalde6ec2c366000a45d20b4a5db26717c7)): ?>
<?php $attributes = $__attributesOriginalde6ec2c366000a45d20b4a5db26717c7; ?>
<?php unset($__attributesOriginalde6ec2c366000a45d20b4a5db26717c7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalde6ec2c366000a45d20b4a5db26717c7)): ?>
<?php $component = $__componentOriginalde6ec2c366000a45d20b4a5db26717c7; ?>
<?php unset($__componentOriginalde6ec2c366000a45d20b4a5db26717c7); ?>
<?php endif; ?>
                                <?php if (isset($component)) { $__componentOriginalc5a5e56244628445de2fc4b6cb73c744 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc5a5e56244628445de2fc4b6cb73c744 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.app-textarea','data' => ['name' => 'message','label' => 'Mensagem','rows' => '4','placeholder' => 'Escreva sua mensagem...','required' => true,'error' => $errors->first('message')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-textarea'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'message','label' => 'Mensagem','rows' => '4','placeholder' => 'Escreva sua mensagem...','required' => true,'error' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->first('message'))]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>
<?php echo e(old('message')); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc5a5e56244628445de2fc4b6cb73c744)): ?>
<?php $attributes = $__attributesOriginalc5a5e56244628445de2fc4b6cb73c744; ?>
<?php unset($__attributesOriginalc5a5e56244628445de2fc4b6cb73c744); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc5a5e56244628445de2fc4b6cb73c744)): ?>
<?php $component = $__componentOriginalc5a5e56244628445de2fc4b6cb73c744; ?>
<?php unset($__componentOriginalc5a5e56244628445de2fc4b6cb73c744); ?>
<?php endif; ?>
                                <?php if (isset($component)) { $__componentOriginald0f1fd2689e4bb7060122a5b91fe8561 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button','data' => ['type' => 'submit','variant' => 'primary']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'submit','variant' => 'primary']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>
Enviar mensagem <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561)): ?>
<?php $attributes = $__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561; ?>
<?php unset($__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald0f1fd2689e4bb7060122a5b91fe8561)): ?>
<?php $component = $__componentOriginald0f1fd2689e4bb7060122a5b91fe8561; ?>
<?php unset($__componentOriginald0f1fd2689e4bb7060122a5b91fe8561); ?>
<?php endif; ?>
                            </form>
                        </div>
                    </div>
                </div>
            </section>

            
            <div class="border-t border-gray-200 dark:border-gray-800 py-4">
                <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-sm text-gray-500 dark:text-gray-400">
                    <span>© <?php echo e(date('Y')); ?> <?php echo e(isset($profile) ? $profile->name : 'Portfolio'); ?>.</span>
                    <div class="flex gap-4">
                        <a href="https://github.com/pvitorv/kit-components" target="_blank" rel="noopener noreferrer" class="hover:underline">Kit de componentes</a>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(isset($profile) && $profile->linkedin_url): ?>
                            <a href="<?php echo e($profile->linkedin_url); ?>" target="_blank" rel="noopener noreferrer" class="hover:underline">LinkedIn</a>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(isset($profile) && $profile->github_url): ?>
                            <a href="<?php echo e($profile->github_url); ?>" target="_blank" rel="noopener noreferrer" class="hover:underline">GitHub</a>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </div>
                </div>
            </div>
        </footer>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $attributes = $__attributesOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__attributesOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $component = $__componentOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__componentOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\NEWS-PROJECTS\portfolio\resources\views/welcome.blade.php ENDPATH**/ ?>