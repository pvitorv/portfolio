<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['project']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['project']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<div class="space-y-6">
    <?php if (isset($component)) { $__componentOriginalde6ec2c366000a45d20b4a5db26717c7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalde6ec2c366000a45d20b4a5db26717c7 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.app-input','data' => ['name' => 'title','label' => 'Título','value' => old('title', $project->title),'placeholder' => 'Ex: E-commerce Laravel','required' => true,'error' => $errors->first('title')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'title','label' => 'Título','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(old('title', $project->title)),'placeholder' => 'Ex: E-commerce Laravel','required' => true,'error' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->first('title'))]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalde6ec2c366000a45d20b4a5db26717c7)): ?>
<?php $attributes = $__attributesOriginalde6ec2c366000a45d20b4a5db26717c7; ?>
<?php unset($__attributesOriginalde6ec2c366000a45d20b4a5db26717c7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalde6ec2c366000a45d20b4a5db26717c7)): ?>
<?php $component = $__componentOriginalde6ec2c366000a45d20b4a5db26717c7; ?>
<?php unset($__componentOriginalde6ec2c366000a45d20b4a5db26717c7); ?>
<?php endif; ?>

    <?php if (isset($component)) { $__componentOriginalde6ec2c366000a45d20b4a5db26717c7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalde6ec2c366000a45d20b4a5db26717c7 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.app-input','data' => ['name' => 'name','label' => 'Nome curto (opcional)','value' => old('name', $project->name),'placeholder' => 'Ex: E-commerce','hint' => 'Se vazio, usa o título.','error' => $errors->first('name')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'name','label' => 'Nome curto (opcional)','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(old('name', $project->name)),'placeholder' => 'Ex: E-commerce','hint' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('Se vazio, usa o título.'),'error' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->first('name'))]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalde6ec2c366000a45d20b4a5db26717c7)): ?>
<?php $attributes = $__attributesOriginalde6ec2c366000a45d20b4a5db26717c7; ?>
<?php unset($__attributesOriginalde6ec2c366000a45d20b4a5db26717c7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalde6ec2c366000a45d20b4a5db26717c7)): ?>
<?php $component = $__componentOriginalde6ec2c366000a45d20b4a5db26717c7; ?>
<?php unset($__componentOriginalde6ec2c366000a45d20b4a5db26717c7); ?>
<?php endif; ?>

    <?php if (isset($component)) { $__componentOriginalc5a5e56244628445de2fc4b6cb73c744 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc5a5e56244628445de2fc4b6cb73c744 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.app-textarea','data' => ['name' => 'description','label' => 'Descrição','error' => $errors->first('description')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-textarea'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'description','label' => 'Descrição','error' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->first('description'))]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>
<?php echo e(old('description', $project->description)); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc5a5e56244628445de2fc4b6cb73c744)): ?>
<?php $attributes = $__attributesOriginalc5a5e56244628445de2fc4b6cb73c744; ?>
<?php unset($__attributesOriginalc5a5e56244628445de2fc4b6cb73c744); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc5a5e56244628445de2fc4b6cb73c744)): ?>
<?php $component = $__componentOriginalc5a5e56244628445de2fc4b6cb73c744; ?>
<?php unset($__componentOriginalc5a5e56244628445de2fc4b6cb73c744); ?>
<?php endif; ?>

    <?php if (isset($component)) { $__componentOriginalde6ec2c366000a45d20b4a5db26717c7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalde6ec2c366000a45d20b4a5db26717c7 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.app-input','data' => ['name' => 'url','label' => 'URL do projeto','type' => 'url','value' => old('url', $project->url),'placeholder' => 'https://meu-projeto.com','required' => true,'error' => $errors->first('url')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'url','label' => 'URL do projeto','type' => 'url','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(old('url', $project->url)),'placeholder' => 'https://meu-projeto.com','required' => true,'error' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->first('url'))]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalde6ec2c366000a45d20b4a5db26717c7)): ?>
<?php $attributes = $__attributesOriginalde6ec2c366000a45d20b4a5db26717c7; ?>
<?php unset($__attributesOriginalde6ec2c366000a45d20b4a5db26717c7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalde6ec2c366000a45d20b4a5db26717c7)): ?>
<?php $component = $__componentOriginalde6ec2c366000a45d20b4a5db26717c7; ?>
<?php unset($__componentOriginalde6ec2c366000a45d20b4a5db26717c7); ?>
<?php endif; ?>

    <?php if (isset($component)) { $__componentOriginalde6ec2c366000a45d20b4a5db26717c7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalde6ec2c366000a45d20b4a5db26717c7 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.app-input','data' => ['name' => 'github_url','label' => 'Link do repositório no GitHub (opcional)','type' => 'url','value' => old('github_url', $project->github_url ?? ''),'placeholder' => 'https://github.com/usuario/repo','error' => $errors->first('github_url')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'github_url','label' => 'Link do repositório no GitHub (opcional)','type' => 'url','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(old('github_url', $project->github_url ?? '')),'placeholder' => 'https://github.com/usuario/repo','error' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->first('github_url'))]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalde6ec2c366000a45d20b4a5db26717c7)): ?>
<?php $attributes = $__attributesOriginalde6ec2c366000a45d20b4a5db26717c7; ?>
<?php unset($__attributesOriginalde6ec2c366000a45d20b4a5db26717c7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalde6ec2c366000a45d20b4a5db26717c7)): ?>
<?php $component = $__componentOriginalde6ec2c366000a45d20b4a5db26717c7; ?>
<?php unset($__componentOriginalde6ec2c366000a45d20b4a5db26717c7); ?>
<?php endif; ?>

    
    <div class="rounded-xl border border-gray-200 dark:border-gray-700 p-4 space-y-4 bg-gray-50/50 dark:bg-gray-800/30">
        <h3 class="text-sm font-semibold text-gray-800 dark:text-gray-200">Miniatura do card (imagem do projeto)</h3>

        
        <div x-data="thumbnailFetcher()">
            <p class="text-sm text-gray-600 dark:text-gray-400 mb-2">
                <strong>Print automático:</strong> gera um screenshot da primeira página que a URL do projeto abre.
            </p>
            <div class="flex flex-wrap items-center gap-3">
                <button
                    type="button"
                    x-on:click="fetchThumbnail()"
                    x-bind:disabled="loading"
                    class="inline-flex items-center gap-2 px-3 py-2 text-sm font-medium rounded-lg bg-blue-100 dark:bg-blue-900/40 text-blue-800 dark:text-blue-200 hover:bg-blue-200 dark:hover:bg-blue-900/60 disabled:opacity-50"
                >
                    <span x-show="!loading">Gerar print da página (screenshot)</span>
                    <span x-show="loading">Gerando…</span>
                </button>
                <span x-show="message" x-text="message" class="text-sm text-gray-500 dark:text-gray-400"></span>
            </div>
            <p class="mt-1 text-xs text-gray-500 dark:text-gray-500">Se não funcionar (site bloqueado, etc.), use uma das opções abaixo.</p>
        </div>

        <?php if (isset($component)) { $__componentOriginal2c8e768b7b0308b95f33094f8009b269 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2c8e768b7b0308b95f33094f8009b269 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.app-divider','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-divider'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2c8e768b7b0308b95f33094f8009b269)): ?>
<?php $attributes = $__attributesOriginal2c8e768b7b0308b95f33094f8009b269; ?>
<?php unset($__attributesOriginal2c8e768b7b0308b95f33094f8009b269); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2c8e768b7b0308b95f33094f8009b269)): ?>
<?php $component = $__componentOriginal2c8e768b7b0308b95f33094f8009b269; ?>
<?php unset($__componentOriginal2c8e768b7b0308b95f33094f8009b269); ?>
<?php endif; ?>

        
        <div>
            <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Ou envie uma imagem</label>
            <input
                type="file"
                name="thumbnail"
                accept="image/jpeg,image/png,image/jpg,image/gif,image/webp"
                class="block w-full text-sm text-gray-600 dark:text-gray-400 file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:bg-gray-200 file:text-gray-700 dark:file:bg-gray-700 dark:file:text-gray-300"
            />
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($errors->first('thumbnail')): ?>
                <p class="mt-1 text-sm text-red-600 dark:text-red-400"><?php echo e($errors->first('thumbnail')); ?></p>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            <p class="mt-1 text-xs text-gray-500 dark:text-gray-500">JPG, PNG, GIF ou WebP. Até 2 MB.</p>
        </div>

        <?php if (isset($component)) { $__componentOriginal2c8e768b7b0308b95f33094f8009b269 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2c8e768b7b0308b95f33094f8009b269 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.app-divider','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-divider'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2c8e768b7b0308b95f33094f8009b269)): ?>
<?php $attributes = $__attributesOriginal2c8e768b7b0308b95f33094f8009b269; ?>
<?php unset($__attributesOriginal2c8e768b7b0308b95f33094f8009b269); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2c8e768b7b0308b95f33094f8009b269)): ?>
<?php $component = $__componentOriginal2c8e768b7b0308b95f33094f8009b269; ?>
<?php unset($__componentOriginal2c8e768b7b0308b95f33094f8009b269); ?>
<?php endif; ?>

        
        <?php if (isset($component)) { $__componentOriginalde6ec2c366000a45d20b4a5db26717c7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalde6ec2c366000a45d20b4a5db26717c7 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.app-input','data' => ['name' => 'thumbnail_url','label' => 'Ou cole aqui a URL de uma imagem','type' => 'url','value' => old('thumbnail_url', $project->thumbnail_url),'placeholder' => 'https://exemplo.com/imagem.jpg','error' => $errors->first('thumbnail_url'),'xRef' => 'thumbnailInput']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'thumbnail_url','label' => 'Ou cole aqui a URL de uma imagem','type' => 'url','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(old('thumbnail_url', $project->thumbnail_url)),'placeholder' => 'https://exemplo.com/imagem.jpg','error' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->first('thumbnail_url')),'x-ref' => 'thumbnailInput']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalde6ec2c366000a45d20b4a5db26717c7)): ?>
<?php $attributes = $__attributesOriginalde6ec2c366000a45d20b4a5db26717c7; ?>
<?php unset($__attributesOriginalde6ec2c366000a45d20b4a5db26717c7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalde6ec2c366000a45d20b4a5db26717c7)): ?>
<?php $component = $__componentOriginalde6ec2c366000a45d20b4a5db26717c7; ?>
<?php unset($__componentOriginalde6ec2c366000a45d20b4a5db26717c7); ?>
<?php endif; ?>
    </div>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($project->thumbnail_display_url ?? null): ?>
        <div>
            <span class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Preview da miniatura</span>
            <img src="<?php echo e($project->thumbnail_display_url); ?>" alt="" class="max-w-xs rounded-lg border border-gray-200 dark:border-gray-700" />
        </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    <?php if (isset($component)) { $__componentOriginalde6ec2c366000a45d20b4a5db26717c7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalde6ec2c366000a45d20b4a5db26717c7 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.app-input','data' => ['name' => 'order','label' => 'Ordem (número, menor aparece primeiro)','type' => 'number','min' => '0','value' => old('order', $project->order ?? 0),'error' => $errors->first('order')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'order','label' => 'Ordem (número, menor aparece primeiro)','type' => 'number','min' => '0','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(old('order', $project->order ?? 0)),'error' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->first('order'))]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalde6ec2c366000a45d20b4a5db26717c7)): ?>
<?php $attributes = $__attributesOriginalde6ec2c366000a45d20b4a5db26717c7; ?>
<?php unset($__attributesOriginalde6ec2c366000a45d20b4a5db26717c7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalde6ec2c366000a45d20b4a5db26717c7)): ?>
<?php $component = $__componentOriginalde6ec2c366000a45d20b4a5db26717c7; ?>
<?php unset($__componentOriginalde6ec2c366000a45d20b4a5db26717c7); ?>
<?php endif; ?>

    <div>
        <label class="inline-flex items-center gap-2 cursor-pointer">
            <input
                type="checkbox"
                name="is_visible"
                value="1"
                <?php echo e(old('is_visible', $project->is_visible ?? true) ? 'checked' : ''); ?>

                class="rounded border-gray-300 dark:border-gray-600 text-blue-600 focus:ring-blue-500"
            />
            <span class="text-sm font-medium text-gray-700 dark:text-gray-300">Visível no portfolio</span>
        </label>
    </div>
</div>

<script>
function thumbnailFetcher() {
    return {
        loading: false,
        message: '',
        fetchThumbnail() {
            const urlInput = document.querySelector('input[name="url"]');
            const thumbnailInput = this.$refs.thumbnailInput?.querySelector('input') || this.$refs.thumbnailInput;
            const url = urlInput?.value?.trim();
            if (!url) {
                this.message = 'Informe a URL do projeto primeiro.';
                return;
            }
            this.loading = true;
            this.message = '';
            fetch('<?php echo e(route("admin.projects.fetch-thumbnail")); ?>', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json',
                    'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]')?.getAttribute('content') || document.querySelector('input[name="_token"]')?.value
                },
                body: JSON.stringify({ url })
            })
            .then(r => r.json())
            .then(data => {
                if (data.success && data.thumbnail_url && thumbnailInput) {
                    thumbnailInput.value = data.thumbnail_url;
                    this.message = 'Miniatura obtida.';
                } else {
                    this.message = 'Não foi possível obter a miniatura. Preencha manualmente ou tente outra URL.';
                }
            })
            .catch(() => {
                this.message = 'Erro ao buscar. Verifique a URL ou preencha a miniatura manualmente.';
            })
            .finally(() => { this.loading = false; });
        }
    };
}
</script>
<?php /**PATH C:\laragon\www\NEWS-PROJECTS\portfolio\resources\views/admin/projects/_form.blade.php ENDPATH**/ ?>