<?php if (isset($component)) { $__componentOriginal5863877a5171c196453bfa0bd807e410 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5863877a5171c196453bfa0bd807e410 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.app','data' => ['title' => $title ?? 'Admin']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($title ?? 'Admin')]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

    <div class="min-h-screen bg-gray-50 dark:bg-gray-950">
        <?php if (isset($component)) { $__componentOriginal9ad8060e833be98a16aaaccaeef88ec5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ad8060e833be98a16aaaccaeef88ec5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.app-navbar','data' => ['brand' => 'Admin','variant' => 'default']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['brand' => 'Admin','variant' => 'default']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

             <?php $__env->slot('links', null, []); ?> 
                <a href="<?php echo e(route('admin.projects.index')); ?>" class="px-3 py-2 rounded-lg hover:bg-black/5 dark:hover:bg-white/5">Projetos</a>
                <a href="<?php echo e(route('admin.profile.edit')); ?>" class="px-3 py-2 rounded-lg hover:bg-black/5 dark:hover:bg-white/5">Perfil</a>
                <a href="<?php echo e(url('/')); ?>" class="px-3 py-2 rounded-lg hover:bg-black/5 dark:hover:bg-white/5">Ver site</a>
             <?php $__env->endSlot(); ?>
            <div class="flex items-center gap-2">
                <?php if (isset($component)) { $__componentOriginal4ba4b6a015091d2c96934fb516198f40 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4ba4b6a015091d2c96934fb516198f40 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.app-theme-toggle','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-theme-toggle'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4ba4b6a015091d2c96934fb516198f40)): ?>
<?php $attributes = $__attributesOriginal4ba4b6a015091d2c96934fb516198f40; ?>
<?php unset($__attributesOriginal4ba4b6a015091d2c96934fb516198f40); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4ba4b6a015091d2c96934fb516198f40)): ?>
<?php $component = $__componentOriginal4ba4b6a015091d2c96934fb516198f40; ?>
<?php unset($__componentOriginal4ba4b6a015091d2c96934fb516198f40); ?>
<?php endif; ?>
                <form action="<?php echo e(route('logout')); ?>" method="POST" class="inline">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="px-3 py-2 rounded-lg text-sm text-gray-600 dark:text-gray-400 hover:bg-black/5 dark:hover:bg-white/5">Sair</button>
                </form>
            </div>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ad8060e833be98a16aaaccaeef88ec5)): ?>
<?php $attributes = $__attributesOriginal9ad8060e833be98a16aaaccaeef88ec5; ?>
<?php unset($__attributesOriginal9ad8060e833be98a16aaaccaeef88ec5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ad8060e833be98a16aaaccaeef88ec5)): ?>
<?php $component = $__componentOriginal9ad8060e833be98a16aaaccaeef88ec5; ?>
<?php unset($__componentOriginal9ad8060e833be98a16aaaccaeef88ec5); ?>
<?php endif; ?>
        <?php echo e($slot); ?>

    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $attributes = $__attributesOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__attributesOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $component = $__componentOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__componentOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\NEWS-PROJECTS\portfolio\resources\views/components/layouts/admin.blade.php ENDPATH**/ ?>