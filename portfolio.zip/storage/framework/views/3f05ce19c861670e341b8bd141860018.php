<?php if (isset($component)) { $__componentOriginalc8c9fd5d7827a77a31381de67195f0c3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.admin','data' => ['title' => 'Perfil – Admin']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.admin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Perfil – Admin']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

        <main class="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('success')): ?>
                <?php if (isset($component)) { $__componentOriginal698857124c69843c95d3799237fd2d1a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal698857124c69843c95d3799237fd2d1a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.app-alert','data' => ['variant' => 'success','class' => 'mb-6']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['variant' => 'success','class' => 'mb-6']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>
<?php echo e(session('success')); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal698857124c69843c95d3799237fd2d1a)): ?>
<?php $attributes = $__attributesOriginal698857124c69843c95d3799237fd2d1a; ?>
<?php unset($__attributesOriginal698857124c69843c95d3799237fd2d1a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal698857124c69843c95d3799237fd2d1a)): ?>
<?php $component = $__componentOriginal698857124c69843c95d3799237fd2d1a; ?>
<?php unset($__componentOriginal698857124c69843c95d3799237fd2d1a); ?>
<?php endif; ?>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

            <h1 class="text-2xl font-bold text-gray-900 dark:text-white mb-6">Configurações de perfil</h1>
            <p class="text-sm text-gray-500 dark:text-gray-400 mb-6">Estes dados aparecem na página inicial do portfolio (currículo e foto).</p>

            <form action="<?php echo e(route('admin.profile.update')); ?>" method="POST" enctype="multipart/form-data" class="space-y-6">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <?php if (isset($component)) { $__componentOriginal593082f5d9bbe85e64b8909ad2db569b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal593082f5d9bbe85e64b8909ad2db569b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.app-card','data' => ['variant' => 'default','padding' => 'lg']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['variant' => 'default','padding' => 'lg']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

                    <div class="space-y-6">
                        
                        <div>
                            <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Sua foto</label>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($user->photo_display_url): ?>
                                <img src="<?php echo e($user->photo_display_url); ?>" alt="" class="w-24 h-24 rounded-full object-cover border-2 border-gray-200 dark:border-gray-700 mb-2" />
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            <input
                                type="file"
                                name="photo"
                                accept="image/jpeg,image/png,image/jpg,image/gif,image/webp"
                                class="block w-full text-sm text-gray-600 dark:text-gray-400 file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:bg-gray-200 file:text-gray-700 dark:file:bg-gray-700 dark:file:text-gray-300"
                            />
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($errors->first('photo')): ?>
                                <p class="mt-1 text-sm text-red-600 dark:text-red-400"><?php echo e($errors->first('photo')); ?></p>
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            <p class="mt-1 text-xs text-gray-500 dark:text-gray-500">JPG, PNG, GIF ou WebP. Até 2 MB.</p>
                        </div>

                        <?php if (isset($component)) { $__componentOriginalde6ec2c366000a45d20b4a5db26717c7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalde6ec2c366000a45d20b4a5db26717c7 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.app-input','data' => ['name' => 'name','label' => 'Nome','value' => old('name', $user->name),'required' => true,'error' => $errors->first('name')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'name','label' => 'Nome','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(old('name', $user->name)),'required' => true,'error' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->first('name'))]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalde6ec2c366000a45d20b4a5db26717c7)): ?>
<?php $attributes = $__attributesOriginalde6ec2c366000a45d20b4a5db26717c7; ?>
<?php unset($__attributesOriginalde6ec2c366000a45d20b4a5db26717c7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalde6ec2c366000a45d20b4a5db26717c7)): ?>
<?php $component = $__componentOriginalde6ec2c366000a45d20b4a5db26717c7; ?>
<?php unset($__componentOriginalde6ec2c366000a45d20b4a5db26717c7); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginalde6ec2c366000a45d20b4a5db26717c7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalde6ec2c366000a45d20b4a5db26717c7 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.app-input','data' => ['name' => 'email','label' => 'E-mail','type' => 'email','value' => old('email', $user->email),'required' => true,'error' => $errors->first('email')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'email','label' => 'E-mail','type' => 'email','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(old('email', $user->email)),'required' => true,'error' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->first('email'))]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalde6ec2c366000a45d20b4a5db26717c7)): ?>
<?php $attributes = $__attributesOriginalde6ec2c366000a45d20b4a5db26717c7; ?>
<?php unset($__attributesOriginalde6ec2c366000a45d20b4a5db26717c7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalde6ec2c366000a45d20b4a5db26717c7)): ?>
<?php $component = $__componentOriginalde6ec2c366000a45d20b4a5db26717c7; ?>
<?php unset($__componentOriginalde6ec2c366000a45d20b4a5db26717c7); ?>
<?php endif; ?>

                        <?php if (isset($component)) { $__componentOriginalde6ec2c366000a45d20b4a5db26717c7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalde6ec2c366000a45d20b4a5db26717c7 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.app-input','data' => ['name' => 'title','label' => 'Título / Cargo (ex: Desenvolvedor Full Stack)','value' => old('title', $user->title),'error' => $errors->first('title')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'title','label' => 'Título / Cargo (ex: Desenvolvedor Full Stack)','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(old('title', $user->title)),'error' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->first('title'))]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalde6ec2c366000a45d20b4a5db26717c7)): ?>
<?php $attributes = $__attributesOriginalde6ec2c366000a45d20b4a5db26717c7; ?>
<?php unset($__attributesOriginalde6ec2c366000a45d20b4a5db26717c7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalde6ec2c366000a45d20b4a5db26717c7)): ?>
<?php $component = $__componentOriginalde6ec2c366000a45d20b4a5db26717c7; ?>
<?php unset($__componentOriginalde6ec2c366000a45d20b4a5db26717c7); ?>
<?php endif; ?>

                        <?php if (isset($component)) { $__componentOriginalc5a5e56244628445de2fc4b6cb73c744 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc5a5e56244628445de2fc4b6cb73c744 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.app-textarea','data' => ['name' => 'bio','label' => 'Sobre você / Currículo (texto que aparece na página inicial)','error' => $errors->first('bio')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-textarea'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'bio','label' => 'Sobre você / Currículo (texto que aparece na página inicial)','error' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->first('bio'))]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>
<?php echo e(old('bio', $user->bio)); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc5a5e56244628445de2fc4b6cb73c744)): ?>
<?php $attributes = $__attributesOriginalc5a5e56244628445de2fc4b6cb73c744; ?>
<?php unset($__attributesOriginalc5a5e56244628445de2fc4b6cb73c744); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc5a5e56244628445de2fc4b6cb73c744)): ?>
<?php $component = $__componentOriginalc5a5e56244628445de2fc4b6cb73c744; ?>
<?php unset($__componentOriginalc5a5e56244628445de2fc4b6cb73c744); ?>
<?php endif; ?>

                        <?php if (isset($component)) { $__componentOriginalde6ec2c366000a45d20b4a5db26717c7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalde6ec2c366000a45d20b4a5db26717c7 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.app-input','data' => ['name' => 'phone','label' => 'Telefone (opcional)','value' => old('phone', $user->phone),'error' => $errors->first('phone')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'phone','label' => 'Telefone (opcional)','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(old('phone', $user->phone)),'error' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->first('phone'))]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalde6ec2c366000a45d20b4a5db26717c7)): ?>
<?php $attributes = $__attributesOriginalde6ec2c366000a45d20b4a5db26717c7; ?>
<?php unset($__attributesOriginalde6ec2c366000a45d20b4a5db26717c7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalde6ec2c366000a45d20b4a5db26717c7)): ?>
<?php $component = $__componentOriginalde6ec2c366000a45d20b4a5db26717c7; ?>
<?php unset($__componentOriginalde6ec2c366000a45d20b4a5db26717c7); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginalde6ec2c366000a45d20b4a5db26717c7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalde6ec2c366000a45d20b4a5db26717c7 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.app-input','data' => ['name' => 'location','label' => 'Localização (opcional)','value' => old('location', $user->location),'error' => $errors->first('location')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'location','label' => 'Localização (opcional)','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(old('location', $user->location)),'error' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->first('location'))]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalde6ec2c366000a45d20b4a5db26717c7)): ?>
<?php $attributes = $__attributesOriginalde6ec2c366000a45d20b4a5db26717c7; ?>
<?php unset($__attributesOriginalde6ec2c366000a45d20b4a5db26717c7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalde6ec2c366000a45d20b4a5db26717c7)): ?>
<?php $component = $__componentOriginalde6ec2c366000a45d20b4a5db26717c7; ?>
<?php unset($__componentOriginalde6ec2c366000a45d20b4a5db26717c7); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginalde6ec2c366000a45d20b4a5db26717c7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalde6ec2c366000a45d20b4a5db26717c7 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.app-input','data' => ['name' => 'linkedin_url','label' => 'LinkedIn (URL)','type' => 'url','value' => old('linkedin_url', $user->linkedin_url),'placeholder' => 'https://linkedin.com/in/...','error' => $errors->first('linkedin_url')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'linkedin_url','label' => 'LinkedIn (URL)','type' => 'url','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(old('linkedin_url', $user->linkedin_url)),'placeholder' => 'https://linkedin.com/in/...','error' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->first('linkedin_url'))]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalde6ec2c366000a45d20b4a5db26717c7)): ?>
<?php $attributes = $__attributesOriginalde6ec2c366000a45d20b4a5db26717c7; ?>
<?php unset($__attributesOriginalde6ec2c366000a45d20b4a5db26717c7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalde6ec2c366000a45d20b4a5db26717c7)): ?>
<?php $component = $__componentOriginalde6ec2c366000a45d20b4a5db26717c7; ?>
<?php unset($__componentOriginalde6ec2c366000a45d20b4a5db26717c7); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginalde6ec2c366000a45d20b4a5db26717c7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalde6ec2c366000a45d20b4a5db26717c7 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.app-input','data' => ['name' => 'github_url','label' => 'GitHub (URL)','type' => 'url','value' => old('github_url', $user->github_url),'placeholder' => 'https://github.com/...','error' => $errors->first('github_url')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'github_url','label' => 'GitHub (URL)','type' => 'url','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(old('github_url', $user->github_url)),'placeholder' => 'https://github.com/...','error' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->first('github_url'))]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalde6ec2c366000a45d20b4a5db26717c7)): ?>
<?php $attributes = $__attributesOriginalde6ec2c366000a45d20b4a5db26717c7; ?>
<?php unset($__attributesOriginalde6ec2c366000a45d20b4a5db26717c7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalde6ec2c366000a45d20b4a5db26717c7)): ?>
<?php $component = $__componentOriginalde6ec2c366000a45d20b4a5db26717c7; ?>
<?php unset($__componentOriginalde6ec2c366000a45d20b4a5db26717c7); ?>
<?php endif; ?>

                        <div class="border-t border-gray-200 dark:border-gray-700 pt-4">
                            <h3 class="text-sm font-semibold text-gray-800 dark:text-gray-200 mb-2">Alterar senha (deixe em branco para não mudar)</h3>
                            <?php if (isset($component)) { $__componentOriginalde6ec2c366000a45d20b4a5db26717c7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalde6ec2c366000a45d20b4a5db26717c7 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.app-input','data' => ['name' => 'password','label' => 'Nova senha','type' => 'password','error' => $errors->first('password')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'password','label' => 'Nova senha','type' => 'password','error' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->first('password'))]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalde6ec2c366000a45d20b4a5db26717c7)): ?>
<?php $attributes = $__attributesOriginalde6ec2c366000a45d20b4a5db26717c7; ?>
<?php unset($__attributesOriginalde6ec2c366000a45d20b4a5db26717c7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalde6ec2c366000a45d20b4a5db26717c7)): ?>
<?php $component = $__componentOriginalde6ec2c366000a45d20b4a5db26717c7; ?>
<?php unset($__componentOriginalde6ec2c366000a45d20b4a5db26717c7); ?>
<?php endif; ?>
                            <?php if (isset($component)) { $__componentOriginalde6ec2c366000a45d20b4a5db26717c7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalde6ec2c366000a45d20b4a5db26717c7 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.app-input','data' => ['name' => 'password_confirmation','label' => 'Confirmar nova senha','type' => 'password','class' => 'mt-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'password_confirmation','label' => 'Confirmar nova senha','type' => 'password','class' => 'mt-2']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalde6ec2c366000a45d20b4a5db26717c7)): ?>
<?php $attributes = $__attributesOriginalde6ec2c366000a45d20b4a5db26717c7; ?>
<?php unset($__attributesOriginalde6ec2c366000a45d20b4a5db26717c7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalde6ec2c366000a45d20b4a5db26717c7)): ?>
<?php $component = $__componentOriginalde6ec2c366000a45d20b4a5db26717c7; ?>
<?php unset($__componentOriginalde6ec2c366000a45d20b4a5db26717c7); ?>
<?php endif; ?>
                        </div>
                    </div>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal593082f5d9bbe85e64b8909ad2db569b)): ?>
<?php $attributes = $__attributesOriginal593082f5d9bbe85e64b8909ad2db569b; ?>
<?php unset($__attributesOriginal593082f5d9bbe85e64b8909ad2db569b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal593082f5d9bbe85e64b8909ad2db569b)): ?>
<?php $component = $__componentOriginal593082f5d9bbe85e64b8909ad2db569b; ?>
<?php unset($__componentOriginal593082f5d9bbe85e64b8909ad2db569b); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginald0f1fd2689e4bb7060122a5b91fe8561 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button','data' => ['type' => 'submit','variant' => 'primary']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'submit','variant' => 'primary']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>
Salvar perfil <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561)): ?>
<?php $attributes = $__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561; ?>
<?php unset($__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald0f1fd2689e4bb7060122a5b91fe8561)): ?>
<?php $component = $__componentOriginald0f1fd2689e4bb7060122a5b91fe8561; ?>
<?php unset($__componentOriginald0f1fd2689e4bb7060122a5b91fe8561); ?>
<?php endif; ?>
            </form>
        </main>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3)): ?>
<?php $attributes = $__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3; ?>
<?php unset($__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc8c9fd5d7827a77a31381de67195f0c3)): ?>
<?php $component = $__componentOriginalc8c9fd5d7827a77a31381de67195f0c3; ?>
<?php unset($__componentOriginalc8c9fd5d7827a77a31381de67195f0c3); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\NEWS-PROJECTS\portfolio\resources\views/admin/profile/edit.blade.php ENDPATH**/ ?>